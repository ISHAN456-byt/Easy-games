const API_KEY = "your_rawg_api_key";
const gamesContainer = document.getElementById("games-container");

async function fetchGames(query = "") {
    let url = `https://api.rawg.io/api/games?key=${API_KEY}&search=${query}`;
    let response = await fetch(url);
    let data = await response.json();

    displayGames(data.results);
}

function displayGames(games) {
    gamesContainer.innerHTML = "";
    games.forEach(game => {
        let gameCard = document.createElement("div");
        gameCard.classList.add("game-card");

        gameCard.innerHTML = `
            <img src="${game.background_image}" alt="${game.name}">
            <h3>${game.name}</h3>
            <p>Released: ${game.released}</p>
            <a href="https://rawg.io/games/${game.slug}" target="_blank">Download</a>
        `;

        gamesContainer.appendChild(gameCard);
    });
}

// Fetch initial games
fetchGames();

// Search functionality
document.getElementById("searchBox").addEventListener("input", (e) => {
    fetchGames(e.target.value);
});
